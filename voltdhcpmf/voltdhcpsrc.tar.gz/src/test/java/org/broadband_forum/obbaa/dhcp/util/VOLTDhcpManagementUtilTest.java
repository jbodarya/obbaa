/*
 * Copyright 2021 Broadband Forum
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.broadband_forum.obbaa.dhcp.util;

import org.broadband_forum.obbaa.connectors.sbi.netconf.NetconfConnectionManager;
import org.broadband_forum.obbaa.dhcp.Entity;
import org.broadband_forum.obbaa.dhcp.exception.MessageFormatterException;
import org.broadband_forum.obbaa.dhcp.kafka.consumer.DhcpKafkaConsumer;
import org.broadband_forum.obbaa.dhcp.kafka.producer.DhcpKafkaProducer;
import org.broadband_forum.obbaa.dhcp.message.GpbFormatter;
import org.broadband_forum.obbaa.dhcp.message.MessageFormatter;
import org.broadband_forum.obbaa.dhcp.message.ResponseData;
import org.broadband_forum.obbaa.dmyang.dao.DeviceDao;
import org.broadband_forum.obbaa.dmyang.entities.*;
import org.broadband_forum.obbaa.netconf.api.server.notification.NotificationService;
import org.broadband_forum.obbaa.netconf.mn.fwk.server.model.support.utils.TxService;
import org.broadband_forum.obbaa.netconf.server.util.TestUtil;
import org.broadband_forum.obbaa.nf.dao.NetworkFunctionDao;
import org.broadband_forum.obbaa.nf.dao.impl.KafkaTopicPurpose;
import org.broadband_forum.obbaa.nf.entities.KafkaTopic;
import org.broadband_forum.obbaa.nm.devicemanager.DeviceManager;
import org.broadband_forum.obbaa.pma.PmaRegistry;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicLong;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;


public class VOLTDhcpManagementUtilTest {
    private final String ONU_NAME = "onu1";
    private final String ONU_ID = "1";

    TxService m_txService;
    @Mock
    DeviceDao m_deviceDao;
    @Mock
    Device m_onuDevice;
    @Mock
    DeviceMgmt m_deviceMgmt;
    @Mock
    DeviceState m_deviceState;
    @Mock
    DeviceManager m_deviceManager;
    @Mock
    MessageFormatter m_messageFormatter;
    @Mock
    NetworkFunctionDao m_networkFunctionDao;
    @Mock
    DhcpKafkaConsumer m_dhcpKafkaConsumer;
    @Mock
    DhcpKafkaProducer m_dhcpKafkaProducer;
    @Mock
    Object m_notification;
    @Mock
    Map<String, Set<String>> m_kafkaConsumerTopicMap;
    @Mock
    KafkaTopic m_kafkaTopic;
    @Mock
    NetconfConnectionManager m_netconfConnectionManager;
    @Mock
    NotificationService m_notificationService;
    @Mock
    OnuConfigInfo m_onuConfigInfo;
    @Mock
    ResponseData m_responseData;
    @Mock
    Entity m_request;
    @Mock
    PmaRegistry m_pmaRegistry;
    @Mock
    ExpectedAttachmentPoint m_expectedAttachmentPoint;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        m_kafkaTopic.setPurpose(KafkaTopicPurpose.DHCP_RESPONSE.toString());
        m_txService = new TxService();
    }

    @Test
    public void testIsResponseOK() {
        ArrayList<Boolean> responseArray = new ArrayList<>();
        responseArray.add(true);
        responseArray.add(true);
        responseArray.add(true);
        assertTrue(VOLTDhcpManagementUtil.isResponseOK(responseArray));
        responseArray.remove(0);
        responseArray.add(0, false);
        assertFalse(VOLTDhcpManagementUtil.isResponseOK(responseArray));

    }

    @Test
    public void testUpdateKafkaSubscriptions() {
        Set<KafkaTopic> kafkaTopicSet = new HashSet<>();
        kafkaTopicSet.add(m_kafkaTopic);
        when(m_networkFunctionDao.getKafkaConsumerTopics("dhcp1", KafkaTopicPurpose.DHCP_RESPONSE)).thenReturn(kafkaTopicSet);
        m_messageFormatter = new GpbFormatter();
        VOLTDhcpManagementUtil.updateKafkaSubscriptions("dhcp1", m_messageFormatter, m_networkFunctionDao, m_dhcpKafkaConsumer,
                m_kafkaConsumerTopicMap);
        verify(m_dhcpKafkaConsumer, times(1)).updateSubscriberTopics(kafkaTopicSet);
        verify(m_networkFunctionDao, times(1)).getKafkaConsumerTopics("dhcp1", KafkaTopicPurpose.DHCP_RESPONSE);

    }


    @Test
    public void testRemoveSubscriptionsNoEntryInMap() {
        Set<KafkaTopic> kafkaTopicSet = new HashSet<>();
        kafkaTopicSet.add(m_kafkaTopic);
        when(m_kafkaConsumerTopicMap.containsKey("dhcp1")).thenReturn(false);
        VOLTDhcpManagementUtil.removeSubscriptions("dhcp1", m_dhcpKafkaConsumer, m_kafkaConsumerTopicMap);
        verify(m_dhcpKafkaConsumer, never()).removeSubscriberTopics(any());
    }

    @Test
    public void testRemoveSubscriptions() {
        Set<KafkaTopic> kafkaTopicSet = new HashSet<>();
        kafkaTopicSet.add(m_kafkaTopic);
        Set<String> kafkaTopicNameSet = new HashSet<>();
        kafkaTopicNameSet.add("dhcp1-request");
        when(m_kafkaConsumerTopicMap.containsKey("dhcp1")).thenReturn(true);
        when(m_kafkaConsumerTopicMap.get("dhcp1")).thenReturn(kafkaTopicNameSet);
        VOLTDhcpManagementUtil.removeSubscriptions("dhcp1", m_dhcpKafkaConsumer, m_kafkaConsumerTopicMap);
        verify(m_dhcpKafkaConsumer, times(1)).removeSubscriberTopics(any());
    }


    @Test
    public void testSendKafkaMessage() throws MessageFormatterException {
        final HashSet<String> kafkaTopicNamesFinal = new HashSet<>();
        kafkaTopicNamesFinal.add("dhcp1-request");
        when(m_networkFunctionDao.getKafkaTopicNames("dhcp1", KafkaTopicPurpose.DHCP_REQUEST)).thenReturn(kafkaTopicNamesFinal);
        VOLTDhcpManagementUtil.sendKafkaMessage(m_notification, "dhcp1", m_txService, m_networkFunctionDao, m_dhcpKafkaProducer);
        verify(m_dhcpKafkaProducer, times(1)).sendNotification("dhcp1-request", m_notification);
        kafkaTopicNamesFinal.remove("dhcp1-request");
        VOLTDhcpManagementUtil.sendKafkaMessage(m_notification, "dhcp1", m_txService, m_networkFunctionDao, m_dhcpKafkaProducer);
        verify(m_dhcpKafkaProducer, times(1)).sendNotification("dhcp1-request", m_notification);
    }

    @Test
    public void testSendKafkaMessageWhenNoTopicPresent() throws MessageFormatterException {
        final HashSet<String> kafkaTopicNamesFinal = new HashSet<>();
        when(m_networkFunctionDao.getKafkaTopicNames("dhcp1", KafkaTopicPurpose.DHCP_REQUEST)).thenReturn(kafkaTopicNamesFinal);
        VOLTDhcpManagementUtil.sendKafkaMessage(m_notification, "dhcp1", m_txService, m_networkFunctionDao, m_dhcpKafkaProducer);
        verify(m_dhcpKafkaProducer, times(0)).sendNotification("dhcp1-request", m_notification);
    }

    @Test
    public void testSetMessageId() {
        AtomicLong messageId = new AtomicLong(0);
        VOLTDhcpManagementUtil.setMessageId(m_request, messageId);
        verify(m_request, times(1)).setMessageId("1");
        VOLTDhcpManagementUtil.setMessageId(m_request, messageId);
        verify(m_request, times(1)).setMessageId("2");
    }

    @Test
    public void TestGenerateRandomMessageId() {
        String messageId = VOLTDhcpManagementUtil.generateRandomMessageId();
        assertNotNull(messageId);
    }

    private String prepareJsonResponseFromFile(String name) {
        return TestUtil.loadAsString(name).trim();
    }
}
